# Titanic Survival Prediction

यह छोटा‑सा प्रोजेक्ट Titanic dataset पर Logistic Regression मॉडल बनाता है — जो यह predict करेगा कि कौन सा passenger बच सकता था।  
प्रोजेक्ट में sample dataset शामिल है; आप चाहें तो Kaggle का पूरा `train.csv` उसी `dataset/` फ़ोल्डर में रखकर भी चला सकते हैं।

## फ़ाइल संरचना
```
Titanic_Survival_Prediction/
│── README.md
│── requirements.txt
│── titanic_model.py
│── titanic_model.ipynb
│── dataset/
    └── titanic_sample.csv
```

## कैसे चलाएँ (Windows / Linux)
1. एक virtual environment बनाइए:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux/Mac
   venv\Scripts\activate    # Windows
   ```
2. आवश्यक पैकेज इन्स्टॉल करें:
   ```bash
   pip install -r requirements.txt
   ```
3. स्क्रिप्ट चलाएँ:
   ```bash
   python titanic_model.py
   ```
   या Jupyter Notebook खोलें:
   ```bash
   jupyter notebook titanic_model.ipynb
   ```

## नोट्स
- `dataset/titanic_sample.csv` एक छोटा sample है ताकि स्क्रिप्ट तुरंत चले। अगर आप Kaggle से पूरा `train.csv` डाउनलोड करके `dataset/titanic.csv` नाम से रखेंगे, तो मॉडल वही डेटा उपयोग करेगा और परिणाम बेहतर आएँगे।
- README में दिए गए steps follow करें और ज़रूरत हो तो मैं Zip में बदलाव कर दूँगा।


## Visuals
नीचे कुछ ग्राफ़्स का उदाहरण है:

![Sample Visualization](screenshot.png)
